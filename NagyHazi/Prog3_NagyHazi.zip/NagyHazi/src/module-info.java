/**
 * 
 */
/**
 * 
 */
module NagyHazi {
	requires java.desktop;
	requires jdk.incubator.vector;
	requires org.junit.jupiter.api;
    exports NagyHazi;
}